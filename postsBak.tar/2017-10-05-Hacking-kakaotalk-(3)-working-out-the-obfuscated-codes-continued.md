---
layout: post
title: "Hacking kakaotalk (3): working out the obfuscated codes continued"
date: 2017-10-05 09:00:00 -0100
categories: hacking
---
## Use [**`simplify`**](https://github.com/CalebFenton/simplify)
g
Follow the install instructions from the link:
1. `git clone --recursive https://github.com/CalebFenton/simplify.git`
2. `./gradlew fatjar`
3. run `simplify.jar` from `simplify/build/libs/simplify.jar`.

## Checkpoint

