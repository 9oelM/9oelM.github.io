---
layout: post
title: "CCNA Notes"
date: 2018-04-07 09:00:00 -0100
categories: network
---
## FYI
It was just too hard to move all the texts and images again to this blog again from [my previous blog](https://7oel.weebly.com/), [so here's the link to the notes on Cisco Certified Network Associate that I wrote on my own: LINK](https://7oel.weebly.com/ccna.html)