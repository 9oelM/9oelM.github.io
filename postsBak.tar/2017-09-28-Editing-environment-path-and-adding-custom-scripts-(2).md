---
layout: post
date: 2017-09-28 09:00:00 -0100
categories: linux
title: Editing environment path and adding custom scripts (2)
---
I wanted to add all subdirectories of `usr/local/bin` as environment path, but [that's not what something people recommended](https://unix.stackexchange.com/questions/17715/how-can-i-set-all-subdirectories-of-a-directory-into-path). People say it's _dangerous_.
