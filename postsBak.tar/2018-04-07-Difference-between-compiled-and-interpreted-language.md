---
layout: post
title: "Difference between compiled and interpreted language"
date: 2018-04-07 09:00:00 -0100
categories: knowledge
---
## FYI
It was just too hard to move all the texts and images again to this blog again from [my previous blog](https://7oel.weebly.com/), [so here's the link to the notes on compiled and interpreted language: LINK](https://7oel.weebly.com/8-whats-the-difference-between-compiled-language-and-interpreted-language.html)