---
layout: post
title: "Presentation design: Marketing project on Spotify"
date: 2018-04-08 09:00:00 -0100
categories: works
---
![1](https://7oel.weebly.com/uploads/9/5/6/3/95631532/first-slide_orig.png)
![2](https://7oel.weebly.com/uploads/9/5/6/3/95631532/slide1_1.jpg)
![3](https://7oel.weebly.com/uploads/9/5/6/3/95631532/slide2.jpg)
![4](https://7oel.weebly.com/uploads/9/5/6/3/95631532/slide3.jpg)
![5](https://7oel.weebly.com/uploads/9/5/6/3/95631532/slide4.jpg)
![6](https://7oel.weebly.com/uploads/9/5/6/3/95631532/slide5.jpg)
![7](https://7oel.weebly.com/uploads/9/5/6/3/95631532/slide6.jpg)
![8](https://7oel.weebly.com/uploads/9/5/6/3/95631532/slide7.jpg)
![9](https://7oel.weebly.com/uploads/9/5/6/3/95631532/slide8.jpg)
![10](https://7oel.weebly.com/uploads/9/5/6/3/95631532/slide9.jpg)
![11](https://7oel.weebly.com/uploads/9/5/6/3/95631532/slide10.jpg)
![12](https://7oel.weebly.com/uploads/9/5/6/3/95631532/slide11.jpg)
![13](https://7oel.weebly.com/uploads/9/5/6/3/95631532/slide14.jpg)
![14](https://7oel.weebly.com/uploads/9/5/6/3/95631532/slide15.jpg)
![15](https://7oel.weebly.com/uploads/9/5/6/3/95631532/slide18.jpg)
![16](https://7oel.weebly.com/uploads/9/5/6/3/95631532/slide19.jpg)
![17](https://7oel.weebly.com/uploads/9/5/6/3/95631532/slide29.jpg)
![18](https://7oel.weebly.com/uploads/9/5/6/3/95631532/slide31.jpg)
![19](https://7oel.weebly.com/uploads/9/5/6/3/95631532/slide32.jpg)