---
layout: post
title: "Books to buy or print"
date: 2018-04-25 09:00:00 -0100
categories: general
---
I want to buy English books but they are too expensive in Korea......

* [Learning React (2018)](http://book.interpark.com/product/BookDisplay.do?_method=detail&sc.shopNo=0000400000&sc.prdNo=279194489&sc.saNo=003002001&bid1=search&bid2=product&bid3=title&bid4=001) - definitely
* [Building Progressive Web Apps: Bringing the Power of Native to the Browser](https://www.amazon.com/Building-Progressive-Web-Apps-Bringing/dp/1491961651/ref=pd_sim_14_28?_encoding=UTF8&pd_rd_i=1491961651&pd_rd_r=NCR51M576RW3WWC99ZZF&pd_rd_w=oPfU8&pd_rd_wg=3s8Qc&psc=1&refRID=NCR51M576RW3WWC99ZZF), but too expensive.
* [DOM Enlightenment (2013): Exploring JavaScript and the Modern DOM](http://book.interpark.com/product/BookDisplay.do?_method=detail&sc.shopNo=0000400000&sc.prdNo=213427270&sc.saNo=003002001&bid1=search&bid2=product&bid3=title&bid4=001) - definitely
* [Testable JavaScript: Ensuring Reliable Code](https://www.amazon.com/Testable-JavaScript-Ensuring-Reliable-Code/dp/1449323391/ref=sr_1_1?s=books&ie=UTF8&qid=1524666024&sr=1-1&keywords=Testable+JavaScript%3A+Ensuring+Reliable+Code)
* [Node.js 마이크로서비스 코딩 공작소 : 마이크로서비스 아키텍처 설계와 구현, 장애 처리, 보안, 로그 수집, 배포까지](http://book.interpark.com/product/BookDisplay.do?_method=detail&sc.shopNo=0000400000&sc.prdNo=279599041&sc.saNo=003002001&bid1=search&bid2=product&bid3=title&bid4=001) - definitely