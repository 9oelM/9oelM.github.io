---
layout: post
title: "List of curated websites(pages) helpful for development"
date: 2018-04-22 09:00:00 -0100
categories: development
---
* [velopert.com](https://velopert.com/about): Front and backend tips, in Korean. 
    * [launching react with express.js](https://velopert.com/1492) 
* [kesus kim](https://blog.kesuskim.com/): Front and backend tips, in Korean.
    * [integrating next.js with node.js (Express)](https://blog.kesuskim.com/2017/07/develop-website-using-next-js/)