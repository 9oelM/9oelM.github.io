---
layout: post
title: "Making a symlink"
date: 2017-10-05 09:00:00 -0100
categories: linux
---
## [How to](https://stackoverflow.com/questions/1951742/how-to-symlink-a-file-in-linux)
Create a symlink
```
ln -s /path/to/file /path/to/symlink
```
Create/update a symlink
```
ln -sf /path/to/file /path/to/symlink
```
