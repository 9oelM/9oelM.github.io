---
layout: post
title: "Error page and no search result page for Grafolio mobile app"
date: 2018-04-07 09:00:00 -0100
categories: works
---
![first](https://7oel.weebly.com/uploads/9/5/6/3/95631532/grafolio-networkerror-ver15artboard-1-2x_orig.png)
![second](https://7oel.weebly.com/uploads/9/5/6/3/95631532/grafolio-searcherror-ver20bartboard-1-2x_orig.png)
![third](https://7oel.weebly.com/uploads/9/5/6/3/95631532/427559673_orig.png)
![fourth](https://7oel.weebly.com/uploads/9/5/6/3/95631532/new_orig.png)