---
layout: post
title: "Screenshotting on Kali"
date: 2017-10-05 09:00:00 -0100
categories: linux
---
## How to
The entire screen
```
Prt Sc 
```
Partial screen
```
shift + Prt sc
```
